These textures were all taken from https://freepbr.com/

