declare module '*.vert' {
  const code: string;
  export default code;
}
