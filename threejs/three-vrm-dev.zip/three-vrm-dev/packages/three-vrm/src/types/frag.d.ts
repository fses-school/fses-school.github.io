declare module '*.frag' {
  const code: string;
  export default code;
}
